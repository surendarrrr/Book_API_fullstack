import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Book } from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private baseUrl = 'http://localhost:8090/books';

  constructor(private http: HttpClient) {}

  // Get all books
  getAllBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.baseUrl}/all`)
      .pipe(catchError(this.handleError));
  }

  // Get book by ISBN
  getBookByIsbn(isbn: number): Observable<Book> {
    return this.http.get<Book>(`${this.baseUrl}/${isbn}`)
      .pipe(catchError(this.handleError));
  }

  // Add new book
  addBook(book: Book): Observable<Book> {
    return this.http.post<Book>(this.baseUrl, book)
      .pipe(catchError(this.handleError));
  }

  // Update book
  updateBook(isbn: number, book: Book): Observable<Book> {
    return this.http.put<Book>(`${this.baseUrl}/${isbn}`, book)
      .pipe(catchError(this.handleError));
  }

  // Delete book
  deleteBook(isbn: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${isbn}`)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An error occurred';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(() => errorMessage);
  }
}
