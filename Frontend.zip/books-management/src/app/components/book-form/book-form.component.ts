import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../../services/book.service';
import { Book } from '../../models/book.model';

@Component({
  selector: 'app-book-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="book-form-container">
      <h2>{{ isEdit ? 'Edit Book' : 'Add New Book' }}</h2>
      
      <form (ngSubmit)="onSubmit()" #bookForm="ngForm">
        <div class="form-group">
          <label for="isbn">ISBN:</label>
          <input 
            type="number" 
            id="isbn" 
            name="isbn" 
            [(ngModel)]="book.isbn" 
            [disabled]="isEdit"
            required 
            #isbn="ngModel"
            class="form-control">
          <div class="error-message" *ngIf="isbn.invalid && isbn.touched">
            ISBN is required
          </div>
        </div>

        <div class="form-group">
          <label for="title">Title:</label>
          <input 
            type="text" 
            id="title" 
            name="title" 
            [(ngModel)]="book.title" 
            required 
            #title="ngModel"
            class="form-control">
          <div class="error-message" *ngIf="title.invalid && title.touched">
            Title is required
          </div>
        </div>

        <div class="form-group">
          <label for="author">Author:</label>
          <input 
            type="text" 
            id="author" 
            name="author" 
            [(ngModel)]="book.author" 
            required 
            #author="ngModel"
            class="form-control">
          <div class="error-message" *ngIf="author.invalid && author.touched">
            Author is required
          </div>
        </div>

        <div class="form-group">
          <label for="publicationYear">Publication Year:</label>
          <input 
            type="number" 
            id="publicationYear" 
            name="publicationYear" 
            [(ngModel)]="book.publicationYear" 
            required 
            min="1000" 
            max="2024"
            #year="ngModel"
            class="form-control">
          <div class="error-message" *ngIf="year.invalid && year.touched">
            <span *ngIf="year.errors?.['required']">Publication year is required</span>
            <span *ngIf="year.errors?.['min'] || year.errors?.['max']">Year must be between 1000 and 2024</span>
          </div>
        </div>

        <div class="form-actions">
          <button type="submit" [disabled]="bookForm.invalid || loading" class="btn btn-primary">
            {{ loading ? 'Saving...' : (isEdit ? 'Update Book' : 'Add Book') }}
          </button>
          <button type="button" (click)="goBack()" class="btn btn-secondary">Cancel</button>
        </div>
      </form>

      <div class="error" *ngIf="error">{{ error }}</div>
    </div>
  `,
  styles: [`
    .book-form-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #333;
    }
    
    .form-control {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 16px;
    }
    
    .form-control:focus {
      outline: none;
      border-color: #007bff;
      box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
    }
    
    .form-control:disabled {
      background-color: #f8f9fa;
      cursor: not-allowed;
    }
    
    .error-message {
      color: #dc3545;
      font-size: 14px;
      margin-top: 5px;
    }
    
    .form-actions {
      display: flex;
      gap: 10px;
      margin-top: 30px;
    }
    
    .btn {
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }
    
    .btn-primary {
      background: #007bff;
      color: white;
    }
    
    .btn-secondary {
      background: #6c757d;
      color: white;
    }
    
    .btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .btn:hover:not(:disabled) {
      opacity: 0.9;
    }
    
    .error {
      color: #dc3545;
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      border-radius: 4px;
      padding: 10px;
      margin-top: 20px;
    }
  `]
})
export class BookFormComponent implements OnInit {
  book: Book = {
    isbn: 0,
    title: '',
    author: '',
    publicationYear: new Date().getFullYear()
  };
  
  isEdit = false;
  loading = false;
  error: string | null = null;

  constructor(
    private bookService: BookService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    const isbn = this.route.snapshot.params['isbn'];
    if (isbn) {
      this.isEdit = true;
      this.loadBook(+isbn);
    }
  }

  loadBook(isbn: number) {
    this.loading = true;
    this.bookService.getBookByIsbn(isbn).subscribe({
      next: (book) => {
        this.book = book;
        this.loading = false;
      },
      error: (error) => {
        this.error = error;
        this.loading = false;
      }
    });
  }

  onSubmit() {
    if (this.isEdit) {
      this.updateBook();
    } else {
      this.addBook();
    }
  }

  addBook() {
    this.loading = true;
    this.error = null;
    
    this.bookService.addBook(this.book).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        this.error = error;
        this.loading = false;
      }
    });
  }

  updateBook() {
    this.loading = true;
    this.error = null;
    
    this.bookService.updateBook(this.book.isbn, this.book).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        this.error = error;
        this.loading = false;
      }
    });
  }

  goBack() {
    this.router.navigate(['/']);
  }
}