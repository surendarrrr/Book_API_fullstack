import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookService } from '../../services/book.service';
import { Book } from '../../models/book.model';

@Component({
  selector: 'app-book-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="search-container">
      <h2>Search Book by ISBN</h2>
      
      <div class="search-form">
        <input 
          type="number" 
          [(ngModel)]="searchIsbn" 
          placeholder="Enter ISBN"
          class="search-input">
        <button (click)="searchBook()" [disabled]="!searchIsbn || loading" class="btn btn-search">
          {{ loading ? 'Searching...' : 'Search' }}
        </button>
      </div>

      <div class="error" *ngIf="error">{{ error }}</div>
      
      <div class="search-result" *ngIf="foundBook">
        <h3>Book Found</h3>
        <div class="book-details">
          <p><strong>ISBN:</strong> {{ foundBook.isbn }}</p>
          <p><strong>Title:</strong> {{ foundBook.title }}</p>
          <p><strong>Author:</strong> {{ foundBook.author }}</p>
          <p><strong>Publication Year:</strong> {{ foundBook.publicationYear }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .search-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .search-form {
      display: flex;
      gap: 10px;
      margin: 20px 0;
    }
    
    .search-input {
      flex: 1;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 16px;
    }
    
    .btn-search {
      padding: 10px 20px;
      background: #28a745;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .btn-search:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .search-result {
      margin-top: 20px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      background: #f8f9fa;
    }
    
    .book-details p {
      margin: 10px 0;
      color: #333;
    }
    
    .error {
      color: #dc3545;
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      border-radius: 4px;
      padding: 10px;
      margin: 20px 0;
    }
  `]
})
export class BookSearchComponent {
  searchIsbn: number | null = null;
  foundBook: Book | null = null;
  loading = false;
  error: string | null = null;

  constructor(private bookService: BookService) {}

  searchBook() {
    if (!this.searchIsbn) return;
    
    this.loading = true;
    this.error = null;
    this.foundBook = null;
    
    this.bookService.getBookByIsbn(this.searchIsbn).subscribe({
      next: (book) => {
        this.foundBook = book;
        this.loading = false;
      },
      error: (error) => {
        this.error = error;
        this.loading = false;
      }
    });
  }
}