import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookService } from '../../services/book.service';
import { Book } from '../../models/book.model';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="book-list-container">
      <h2>All Books</h2>
      <div class="loading" *ngIf="loading">Loading books...</div>
      <div class="error" *ngIf="error">{{ error }}</div>
      
      <div class="books-grid" *ngIf="!loading && !error">
        <div class="book-card" *ngFor="let book of books">
          <h3>{{ book.title }}</h3>
          <p><strong>Author:</strong> {{ book.author }}</p>
          <p><strong>ISBN:</strong> {{ book.isbn }}</p>
          <p><strong>Year:</strong> {{ book.publicationYear }}</p>
          <div class="book-actions">
            <button class="btn btn-edit" (click)="editBook(book)">Edit</button>
            <button class="btn btn-delete" (click)="deleteBook(book.isbn)">Delete</button>
          </div>
        </div>
      </div>
      
      <div class="empty-state" *ngIf="!loading && !error && books.length === 0">
        <p>No books found. Add your first book!</p>
      </div>
    </div>
  `,
  styles: [`
    .book-list-container {
      padding: 20px;
    }
    
    .books-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    
    .book-card {
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      background: white;
    }
    
    .book-card h3 {
      margin: 0 0 10px 0;
      color: #333;
    }
    
    .book-card p {
      margin: 5px 0;
      color: #666;
    }
    
    .book-actions {
      margin-top: 15px;
      display: flex;
      gap: 10px;
    }
    
    .btn {
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }
    
    .btn-edit {
      background: #007bff;
      color: white;
    }
    
    .btn-delete {
      background: #dc3545;
      color: white;
    }
    
    .btn:hover {
      opacity: 0.8;
    }
    
    .loading, .error {
      text-align: center;
      padding: 20px;
      margin: 20px 0;
    }
    
    .error {
      color: #dc3545;
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      border-radius: 4px;
    }
    
    .empty-state {
      text-align: center;
      padding: 40px;
      color: #666;
    }
  `]
})
export class BookListComponent implements OnInit {
  books: Book[] = [];
  loading = false;
  error: string | null = null;

  constructor(private bookService: BookService) {}

  ngOnInit() {
    this.loadBooks();
  }

  loadBooks() {
    this.loading = true;
    this.error = null;
    
    this.bookService.getAllBooks().subscribe({
      next: (books) => {
        this.books = books;
        this.loading = false;
      },
      error: (error) => {
        this.error = error;
        this.loading = false;
      }
    });
  }

  editBook(book: Book) {
    // This will be implemented when we add the edit functionality
    console.log('Edit book:', book);
  }

  deleteBook(isbn: number) {
    if (confirm('Are you sure you want to delete this book?')) {
      this.bookService.deleteBook(isbn).subscribe({
        next: () => {
          this.loadBooks(); // Refresh the list
        },
        error: (error) => {
          this.error = error;
        }
      });
    }
  }
}